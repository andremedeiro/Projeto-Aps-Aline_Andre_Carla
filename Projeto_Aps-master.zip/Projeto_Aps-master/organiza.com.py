from sistema import Sistema

sistema = Sistema()
opcao= ''
while opcao != 'x':
    opcao = sistema.menu()
